TCP texts
