AGORA project
